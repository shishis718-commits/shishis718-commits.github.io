(function () {
  const select = document.getElementById('theme-select');
  if (!select) return;
  const allowed = ['paper', 'night', 'scrapbook', 'editorial'];
  let saved = 'paper';
  try { saved = localStorage.getItem('paper-planet-theme') || 'paper'; } catch (e) {}
  if (!allowed.includes(saved)) saved = 'paper';
  document.body.dataset.theme = saved;
  select.value = saved;
  select.addEventListener('change', function () {
    const next = allowed.includes(select.value) ? select.value : 'paper';
    document.body.dataset.theme = next;
    try { localStorage.setItem('paper-planet-theme', next); } catch (e) {}
  });
})();
